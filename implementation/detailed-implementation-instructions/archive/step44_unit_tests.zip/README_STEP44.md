\
# I-28 Step 44 — Unit Tests

This test suite covers the five Step 44 requirements:

1. Schema validation
2. User isolation logic
3. Candidate rejection
4. Duplicate prevention
5. Active/deleted filtering

## Run

From the Azure Functions project root, with the project virtual environment active:

```powershell
python -m pip install -r requirements-dev.txt
python -m pytest
```

Expected result: all tests pass with no access to the development Cosmos memories
container.

These are unit tests. Cosmos integration testing belongs to I-28 Step 45.

## Files

- `tests/test_memory_schema.py`
- `tests/test_memory_validation.py`
- `tests/test_memory_isolation.py`
- `tests/test_memory_deduplication.py`
- `tests/test_memory_filtering.py`
- `tests/conftest.py`
- `pytest.ini`
- `requirements-dev.txt`


## Optional PowerShell runner

Install dev dependencies and run:

```powershell
.\run_step44_tests.ps1 -Install
```

After the first install, run:

```powershell
.\run_step44_tests.ps1
```
