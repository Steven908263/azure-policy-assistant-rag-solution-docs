\
import importlib
import os
import sys

import pytest


# Set safe, synthetic values BEFORE function_app is imported.
# No real credentials or production endpoints are required for Step 44 unit tests.
_UNIT_TEST_ENV = {
    "AzureWebJobsStorage": "UseDevelopmentStorage=true",
    "FUNCTIONS_WORKER_RUNTIME": "python",
    "AZURE_SEARCH_ENDPOINT": "https://unit-test.search.windows.net",
    "AZURE_SEARCH_INDEX_NAME": "unit-test-index",
    "AZURE_SEARCH_CONTENT_FIELD": "chunk",
    "AZURE_SEARCH_VECTOR_FIELD": "text_vector",
    "AZURE_SEARCH_SOURCE_FIELD": "title",
    "AZURE_OPENAI_ENDPOINT": "https://unit-test.openai.azure.com",
    "AZURE_OPENAI_DEPLOYMENT": "unit-test-deployment",
    "COSMOS_ENDPOINT": "https://unit-test.documents.azure.com:443/",
    "COSMOS_DATABASE": "unit-test-db",
    "COSMOS_DATABASE_NAME": "unit-test-db",
    "COSMOS_CONVERSATIONS_CONTAINER": "conversations",
    "COSMOS_MESSAGES_CONTAINER": "messages",
    "COSMOS_MEMORIES_CONTAINER": "memories",
    "ENTRA_TENANT_ID": "00000000-0000-4000-8000-000000000001",
    "ENTRA_API_CLIENT_ID": "00000000-0000-4000-8000-000000000002",
    "OBO_TENANT_ID": "00000000-0000-4000-8000-000000000001",
    "OBO_CLIENT_ID": "00000000-0000-4000-8000-000000000002",
    "OBO_CLIENT_SECRET": "unit-test-secret-not-real",
    "POLICY_SYSTEM_PROMPT_VERSION": "3.0",
    "POLICY_SYSTEM_PROMPT_FILE": "prompts/policy_assistant_system_v3.txt",
    "LONG_TERM_MEMORY_MAX_ITEM_CHARS": "1000",
    "LONG_TERM_MEMORY_MIN_CONFIDENCE": "0.75",
    "LONG_TERM_MEMORY_MIN_IMPORTANCE": "0.50",
    "LONG_TERM_MEMORY_ENABLED": "true",
    "MEMORY_DEV_VALIDATION_ENABLED": "false",
}


for _name, _value in _UNIT_TEST_ENV.items():
    os.environ.setdefault(_name, _value)


@pytest.fixture(scope="session")
def app_module():
    """
    Import the real orchestration module once.

    These are unit tests: individual tests replace the Cosmos memories container
    and other collaborators with fakes/monkeypatches before exercising behavior.
    """
    if "function_app" in sys.modules:
        module = sys.modules["function_app"]
    else:
        module = importlib.import_module("function_app")

    return module


@pytest.fixture
def valid_memory_candidate():
    """
    Canonical candidate that should pass the I-28 server-side validation gate.
    """
    return {
        "type": "project_context",
        "memoryKey": "current_ai_project",
        "content": "User is building the Corporate Policy Assistant.",
        "confidence": 0.95,
        "importance": 0.80,
        "isDurable": True,
        "usefulAcrossConversations": True,
        "isOneTime": False,
        "isTransient": False,
        "containsCurrentPolicyEvidence": False,
        "isTransientQuestion": False,
        "containsSecretOrToken": False,
        "containsAuthorizationId": False,
        "containsRestrictedPolicyContent": False,
        "containsRawPolicyText": False,
        "isFullConversationTranscript": False,
    }


class FakeMemoriesContainer:
    """
    Minimal Cosmos-container fake used by Step 44 unit tests.

    It records calls but does not connect to Cosmos DB.
    """

    def __init__(self, *, read_item_result=None, query_results=None):
        self.read_item_result = read_item_result
        self.query_results = list(query_results or [])
        self.read_calls = []
        self.query_calls = []
        self.create_calls = []
        self.patch_calls = []
        self.delete_calls = []

    def read_item(self, *, item, partition_key):
        self.read_calls.append(
            {"item": item, "partition_key": partition_key}
        )
        if isinstance(self.read_item_result, Exception):
            raise self.read_item_result
        return self.read_item_result

    def query_items(self, *, query, parameters, partition_key, **kwargs):
        self.query_calls.append(
            {
                "query": query,
                "parameters": parameters,
                "partition_key": partition_key,
                **kwargs,
            }
        )
        return list(self.query_results)

    def create_item(self, *, body):
        self.create_calls.append({"body": body})
        return dict(body)

    def patch_item(self, *, item, partition_key, patch_operations):
        self.patch_calls.append(
            {
                "item": item,
                "partition_key": partition_key,
                "patch_operations": patch_operations,
            }
        )
        return {
            "id": item,
            "memoryId": item,
            "userId": partition_key,
        }

    def delete_item(self, *, item, partition_key):
        self.delete_calls.append(
            {"item": item, "partition_key": partition_key}
        )
